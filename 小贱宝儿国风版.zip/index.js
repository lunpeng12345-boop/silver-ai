'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PORT = 9000;
const MEMORIES_FILE = path.join(__dirname, 'memories.json');
const PHOTOS_DIR = path.join(__dirname, 'photos');

// 确保照片目录存在
if (!fs.existsSync(PHOTOS_DIR)) fs.mkdirSync(PHOTOS_DIR, { recursive: true });

function loadMemories() {
  try {
    if (fs.existsSync(MEMORIES_FILE)) return JSON.parse(fs.readFileSync(MEMORIES_FILE, 'utf8'));
  } catch(e) {}
  return [];
}

function saveMemories(memories) {
  fs.writeFileSync(MEMORIES_FILE, JSON.stringify(memories, null, 2), 'utf8');
}

// 调用千问文字对话
function callQwen(apiKey, messages) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ model: 'qwen-plus', messages, max_tokens: 1000 });
    const options = {
      hostname: 'dashscope.aliyuncs.com',
      path: '/compatible-mode/v1/chat/completions',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'Authorization': `Bearer ${apiKey}`
      }
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch(e) { reject(new Error('Parse error')); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// 调用千问视觉模型（看图写故事）
function callQwenVL(apiKey, imageBase64, mimeType, prompt) {
  return new Promise((resolve, reject) => {
    const messages = [{
      role: 'user',
      content: [
        { type: 'image_url', image_url: { url: `data:${mimeType};base64,${imageBase64}` } },
        { type: 'text', text: prompt }
      ]
    }];
    const body = JSON.stringify({ model: 'qwen-vl-plus', messages, max_tokens: 1000 });
    const options = {
      hostname: 'dashscope.aliyuncs.com',
      path: '/compatible-mode/v1/chat/completions',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'Authorization': `Bearer ${apiKey}`
      }
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch(e) { reject(new Error('Parse error')); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// 解析 multipart/form-data
function parseMultipart(buffer, boundary) {
  const boundaryBuf = Buffer.from('--' + boundary);
  const parts = [];
  let start = 0;
  while (start < buffer.length) {
    const boundaryIdx = buffer.indexOf(boundaryBuf, start);
    if (boundaryIdx === -1) break;
    const headerStart = boundaryIdx + boundaryBuf.length + 2;
    const headerEnd = buffer.indexOf(Buffer.from('\r\n\r\n'), headerStart);
    if (headerEnd === -1) break;
    const headers = buffer.slice(headerStart, headerEnd).toString();
    const contentStart = headerEnd + 4;
    const nextBoundary = buffer.indexOf(boundaryBuf, contentStart);
    const contentEnd = nextBoundary === -1 ? buffer.length : nextBoundary - 2;
    const content = buffer.slice(contentStart, contentEnd);
    const nameMatch = headers.match(/name="([^"]+)"/);
    const filenameMatch = headers.match(/filename="([^"]+)"/);
    const ctMatch = headers.match(/Content-Type: (.+)/);
    if (nameMatch) {
      parts.push({
        name: nameMatch[1],
        filename: filenameMatch ? filenameMatch[1] : null,
        contentType: ctMatch ? ctMatch[1].trim() : 'text/plain',
        data: content
      });
    }
    start = nextBoundary === -1 ? buffer.length : nextBoundary;
  }
  return parts;
}

const HTML_FILE = path.join(__dirname, 'index.html');

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS, GET, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

  // 前端页面
  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    try {
      const html = fs.readFileSync(HTML_FILE, 'utf8');
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.writeHead(200); res.end(html);
    } catch(e) { res.writeHead(500); res.end('页面加载失败'); }
    return;
  }

  // 获取照片
  if (req.method === 'GET' && req.url.startsWith('/photos/')) {
    const filename = req.url.replace('/photos/', '');
    const filepath = path.join(PHOTOS_DIR, filename);
    if (fs.existsSync(filepath)) {
      const ext = path.extname(filename).toLowerCase();
      const mimeTypes = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.gif': 'image/gif', '.webp': 'image/webp' };
      res.setHeader('Content-Type', mimeTypes[ext] || 'image/jpeg');
      res.writeHead(200);
      res.end(fs.readFileSync(filepath));
    } else {
      res.writeHead(404); res.end('Not found');
    }
    return;
  }

  // 上传照片并生成故事
  if (req.method === 'POST' && req.url === '/api/photo-story') {
    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', async () => {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      try {
        const buffer = Buffer.concat(chunks);
        const contentType = req.headers['content-type'] || '';
        const boundaryMatch = contentType.match(/boundary=(.+)/);
        if (!boundaryMatch) { res.writeHead(400); res.end(JSON.stringify({ error: '请求格式错误' })); return; }

        const parts = parseMultipart(buffer, boundaryMatch[1]);
        const filePart = parts.find(p => p.filename);
        const yearPart = parts.find(p => p.name === 'year');
        const peoplePart = parts.find(p => p.name === 'people');
        const contextPart = parts.find(p => p.name === 'context');

        if (!filePart) { res.writeHead(400); res.end(JSON.stringify({ error: '没有找到图片' })); return; }

        // 保存照片到服务器
        const ext = path.extname(filePart.filename || '.jpg');
        const filename = Date.now() + ext;
        const filepath = path.join(PHOTOS_DIR, filename);
        fs.writeFileSync(filepath, filePart.data);

        const apiKey = process.env.DASHSCOPE_API_KEY;
        if (!apiKey) { res.writeHead(500); res.end(JSON.stringify({ error: '未配置API密钥' })); return; }

        // 用视觉模型分析照片
        const imageBase64 = filePart.data.toString('base64');
        const year = yearPart ? yearPart.data.toString().trim() : '';
        const people = peoplePart ? peoplePart.data.toString().trim() : '';
        const context = contextPart ? contextPart.data.toString().trim() : '';

        const prompt = `请根据这张老照片，结合以下信息，写一段温暖感人的回忆故事：
年份：${year || '不确定'}
照片中的人：${people || '家人'}
地点背景：${context || '日常生活'}

要求：文字优美有画面感，200-300字，用第一人称，结合照片里看到的细节，体现时代背景，结尾温暖有余韵。`;

        const result = await callQwenVL(apiKey, imageBase64, filePart.contentType, prompt);
        if (result.status !== 200) {
          res.writeHead(502);
          res.end(JSON.stringify({ error: 'AI分析失败，请重试' }));
          return;
        }

        const story = result.body.choices?.[0]?.message?.content || '无法生成故事，请重试。';
        res.writeHead(200);
        res.end(JSON.stringify({ story, photoUrl: '/photos/' + filename }));

      } catch(err) {
        console.error('Photo story error:', err.message);
        res.writeHead(500);
        res.end(JSON.stringify({ error: '处理失败：' + err.message }));
      }
    });
    return;
  }

  // 获取所有回忆
  if (req.method === 'GET' && req.url === '/api/memories') {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.writeHead(200); res.end(JSON.stringify(loadMemories()));
    return;
  }

  // 保存回忆
  if (req.method === 'POST' && req.url === '/api/memories') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', () => {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      try {
        const memory = JSON.parse(body);
        memory.id = Date.now().toString();
        memory.createdAt = new Date().toLocaleString('zh-CN');
        const memories = loadMemories();
        memories.unshift(memory);
        saveMemories(memories);
        res.writeHead(200); res.end(JSON.stringify({ success: true, memory }));
      } catch(e) { res.writeHead(400); res.end(JSON.stringify({ error: '保存失败' })); }
    });
    return;
  }

  // 删除回忆
  if (req.method === 'DELETE' && req.url.startsWith('/api/memories/')) {
    const id = req.url.replace('/api/memories/', '');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    const memories = loadMemories().filter(m => m.id !== id);
    saveMemories(memories);
    res.writeHead(200); res.end(JSON.stringify({ success: true }));
    return;
  }

  // 导出回忆录
  if (req.method === 'GET' && req.url === '/api/memories/export') {
    const memories = loadMemories();
    const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>我的回忆录</title>
<style>
  body { font-family: "Microsoft YaHei", sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; color: #333; }
  h1 { text-align: center; color: #8B5A3C; font-size: 28px; margin-bottom: 10px; }
  .subtitle { text-align: center; color: #9B7A64; margin-bottom: 40px; }
  .memory { border: 1px solid #E8D4BE; border-radius: 12px; padding: 24px; margin-bottom: 24px; background: #FFFCF8; page-break-inside: avoid; }
  .memory-title { font-size: 20px; font-weight: bold; color: #8B5A3C; margin-bottom: 8px; }
  .memory-meta { font-size: 13px; color: #9B7A64; margin-bottom: 14px; }
  .memory-text { font-size: 16px; line-height: 1.9; white-space: pre-wrap; }
  img { max-width: 100%; border-radius: 8px; margin-bottom: 12px; }
  @media print { body { margin: 20px; } }
</style>
</head>
<body>
<h1>📖 我的回忆录</h1>
<div class="subtitle">导出时间：${new Date().toLocaleString('zh-CN')}</div>
${memories.map(m => `
<div class="memory">
  ${m.photoUrl ? `<img src="http://120.53.16.198:9000${m.photoUrl}" />` : ''}
  <div class="memory-title">${m.title || '无标题'}</div>
  <div class="memory-meta">📅 ${m.year || '时间不详'} | 记录于 ${m.createdAt || ''}</div>
  <div class="memory-text">${m.text || ''}</div>
</div>`).join('')}
</body>
</html>`;
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="memories.html"');
    res.writeHead(200); res.end(html);
    return;
  }

  // AI对话
  if (req.method === 'POST' && req.url === '/api/chat') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', async () => {
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      try {
        const { system, messages } = JSON.parse(body);
        if (!messages || !Array.isArray(messages)) { res.writeHead(400); res.end(JSON.stringify({ error: '请求格式不正确' })); return; }
        const apiKey = process.env.DASHSCOPE_API_KEY;
        if (!apiKey) { res.writeHead(500); res.end(JSON.stringify({ error: '未配置API密钥' })); return; }
        const allMessages = system ? [{ role: 'system', content: system }, ...messages] : messages;
        const result = await callQwen(apiKey, allMessages);
        if (result.status !== 200) { res.writeHead(502); res.end(JSON.stringify({ error: 'AI服务暂时不可用' })); return; }
        const text = result.body.choices?.[0]?.message?.content || '抱歉，请再试一次。';
        res.writeHead(200); res.end(JSON.stringify({ text }));
      } catch (err) {
        res.writeHead(500); res.end(JSON.stringify({ error: '服务器出了点问题' }));
      }
    });
    return;
  }

  res.writeHead(404); res.end('Not found');
});

server.listen(PORT, '0.0.0.0', () => { console.log(`小贱宝儿已启动，端口：${PORT}`); });
